"""路由层：号池 × 上游调用 × 失败切换。

这里解决三个真问题：

1. **失败切换的时机**。非流式很简单，失败就换下一个 Key。流式不行——响应头一发出去就
   无法再改 HTTP 状态码，所以唯一能切换的时机是「连上并且确认状态码 OK」的那一刻。
   `peek_first` 就是干这个的：先把第一个事件拉出来，成功了才把控制权交给调用方。

2. **哪些失败该计入熔断**。429/5xx/连不上是渠道的问题，要熔断；400/404 是我们请求本身
   写得不对（比如模型名错、协议翻译不了），把它算成渠道故障会让整个池子被无辜熔断。

3. **用量记账的完整性**。流式的 usage 在流尾才到，所以不能在返回时就记成功，
   要在流真正跑完后由 `_guard` 补记；客户端中途断开则既不记成功也不记失败。
"""

from __future__ import annotations

import hashlib
import json

from . import secretbox
import re
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterator

from . import upstream
from .pool import KeyPool, UpstreamKey
from .pool import PROTOCOL_ANTHROPIC
from .upstream import UpstreamError, call_embeddings


def classify_upstream_error(detail: str) -> tuple[int, str, str]:
    """上游错误 → (客户端 status, code, 人话)。

    规则**写死并有序**（命中即停），不要让关键词互相抢：
      1) 连不上/超时        → 504 upstream_timeout
      2) 401/403            → 502 upstream_auth        （状态码优先，body 里有 429 字样也不改判）
      3) 429                → quota > rate_limit       （只在 429 内部比关键词）
      4) 400/404/413        → quota > auth > model > 其它
      5) 5xx / 529          → upstream_server / overloaded
    关键词只在 400/404/429 这三个「语义模糊」的状态码上参与细分。
    """
    text = str(detail or "")
    low = text.lower()
    m = re.search(r"HTTP\s*(\d{3})", text)
    status = int(m.group(1)) if m else 0

    if status == 0:
        return 504, "upstream_timeout", "上游超时或无法连接，请稍后重试"
    if status in (401, 403):
        return 502, "upstream_auth", "上游鉴权失败（渠道凭据可能已失效）"

    def has(*words: str) -> bool:
        return any(w in low for w in words)

    if status == 429:
        if has("insufficient_quota", "quota", "balance", "余额", "额度", "欠费"):
            return 502, "upstream_quota", "上游额度已耗尽，请联系管理员"
        return 429, "upstream_rate_limit", "上游限流，请稍后重试"

    if status in (400, 404, 413):
        # 顺序：quota > auth > model > context/content > 兜底
        if has("insufficient_quota", "quota", "balance", "余额", "额度", "欠费"):
            return 502, "upstream_quota", "上游额度已耗尽，请联系管理员"
        if has("invalid_api_key", "invalid api key", "unauthorized", "authentication"):
            return 502, "upstream_auth", "上游鉴权失败（渠道凭据可能已失效）"
        if has("model_not_found", "model not found", "no such model", "unknown model") or re.search(
            r"model\s+\S*\s*not\s+found", low
        ):
            return 502, "upstream_model_missing", "上游没有该模型（渠道映射可能过时）"
        if has("context_length", "too many tokens", "maximum context"):
            return 400, "context_too_long", "请求超出模型上下文长度，请缩短后重试"
        if has("content_filter", "content policy"):
            return 400, "content_filtered", "内容被上游安全策略拦截"
        if status == 413:
            return 413, "payload_too_large", "请求体过大"
        if status == 400:
            return 400, "bad_request", "上游拒绝该请求（参数或内容不合法）"
        # 404 且没有 model 关键词：接口/路径问题，归配置
        return 502, "upstream_endpoint", "上游接口不存在（渠道配置可能过时）"

    if status == 408:
        return 504, "upstream_timeout", "上游超时"
    if status == 529 or has("overloaded"):
        return 503, "upstream_overloaded", "上游过载，请稍后重试"
    if status >= 500:
        return 502, "upstream_server", "上游服务异常"
    return 502, "upstream_error", "上游请求失败"


def public_failure_reason(detail: str) -> str:
    return classify_upstream_error(detail)[2]


def all_failed(attempts: list[str], last: object) -> "RouterError":
    status, code, message = classify_upstream_error(str(last))
    return RouterError(
        f"全部 {len(attempts)} 个渠道都失败：{message}",
        attempts,
        status=status,
        detail=str(last),
        code=code,
        retry_after=getattr(last, "retry_after", None),
    )


class RouterError(RuntimeError):
    """无可用渠道。status 区分「客户端要了个不存在的模型」和「上游全挂了」。

    这个区分有实际意义：模型名不在池里是 404（客户端的错，别去熔断任何 Key），
    所有渠道故障才是 502/503（上游的错）。混成一个会让排查方向完全跑偏。
    """

    def __init__(
        self,
        message: str,
        attempts: list[str] | None = None,
        status: int = 502,
        detail: str = "",
        code: str = "",
        retry_after: int | None = None,
    ) -> None:
        super().__init__(message)
        self.attempts = attempts or []
        self.status = status
        # 上游原始错误：**只给服务端日志**，绝不回给下游（上游可能回显我们的凭证）。
        self.detail = detail
        self.code = code
        self.retry_after = retry_after


@dataclass
class RelayOutcome:
    """一次成功的转发结果。二选一：非流式给 message，流式给 events。

    `model` 是本次实际服务的模型名：HTTP 层要用它把 Anthropic 形态的结果
    编码成 OpenAI 形态（chunk 里必须回填 model），这一步不能靠猜。

    `usage` 是流式场景下的用量承接器（`_TokenSink`）：usage 在流尾才到，
    HTTP 层要在流跑完后读它做按令牌记账。非流式没有这个值——直接读 message 的 usage。
    """

    label: str
    model: str = ""
    message: dict[str, Any] | None = None
    events: Iterator[tuple[str, dict[str, Any]]] | None = None
    attempts: list[str] = field(default_factory=list)
    usage: _TokenSink | None = None
    # 实际服务的上游 Key：service 层用它算 upstream_cost（成本入账）。
    # None = 测试/第三方路由器没带，成本按 0 处理。
    key: Any = None


class _TokenSink:
    """承接流式流尾才到达的 usage。

    缓存字段必须一起接：流尾那份 usage 里就有 `prompt_cache_hit_tokens` /
    `cached_tokens`。早先只接 input/output，等于**流式请求的缓存命中恒记 0**，
    报表永远是假的（非流式反而正常，所以不容易发现）。
    """

    def __init__(self) -> None:
        self.input = 0
        self.output = 0
        self.cache_read = 0
        self.cache_creation = 0

    def __call__(
        self, tokens_in: int, tokens_out: int,
        cache_read: int = 0, cache_creation: int = 0,
    ) -> None:
        self.input = tokens_in
        self.output = tokens_out
        self.cache_read = cache_read
        self.cache_creation = cache_creation


class ExitGuard:
    """出口查重：同一内容指纹在时间窗内对同一上游的发送次数上限。

    与入口 LoopGuard 配对：入口拦「回来的」，出口拦「发出去的」——
    即使入口因内容差异漏判（上游改写了部分参数），同一指纹对同一
    上游的高频重发也会在这里被跳过，候选直接当不可用处理。
    进程内存态，重启清零；窗口 60s、上限 4 次。
    """

    WINDOW = 60.0
    LIMIT = 4

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._sends: dict[tuple[str, str], list[float]] = {}

    def allow(self, fingerprint: str, upstream: str, scope: str = "") -> bool:
        now = time.monotonic()
        with self._lock:
            # scope = 下游身份（令牌哈希/名字）：按「谁」分桶——
            # 一个用户反复发同一句不该占掉另一个用户的短时重发额度。
            key = (scope, fingerprint, upstream)
            hits = [t for t in self._sends.get(key, ()) if now - t < self.WINDOW]
            if len(hits) >= self.LIMIT:
                self._sends[key] = hits
                return False
            hits.append(now)
            self._sends[key] = hits
            if len(self._sends) > 4096:
                self._sends = {k: v for k, v in self._sends.items() if v}
            return True


_EXIT_GUARD = ExitGuard()


class KeyPoolRouter:
    """把请求分发给号池里的真实上游 Key。"""

    def __init__(
        self,
        pool: KeyPool,
        *,
        timeout: float = 120.0,
        stream_timeout: float = 300.0,
        persist_path: Path | None = None,
    ) -> None:
        self.pool = pool
        self.timeout = timeout
        self.stream_timeout = stream_timeout
        self.persist_path = persist_path

    # -- 对外 ------------------------------------------------------------

    def models(self, group: str | None = None) -> dict[str, int]:
        """模型 → 上下文长度（0 表示该 Key 没声明，不要当成真的 0）。

        group 非空时只列该渠道组的模型——下游令牌绑组后可见性的根。
        """
        windows = self.pool.model_windows()
        return {model: windows.get(model, 0) for model in self.pool.all_models(group)}

    def relay(
        self,
        model: str,
        payload: dict[str, Any],
        stream: bool,
        trace_headers: dict[str, str] | None = None,
        fp: str | None = None,
        group: str | None = None,
        guard_scope: str | None = None,
    ) -> RelayOutcome:
        candidates = self.pool.candidates(model, group=group)
        if not candidates:
            declared = any(key.supports(model) for key in self.pool.keys)
            raise RouterError(
                self._no_candidate_reason(model),
                status=503 if declared else 404,
            )

        attempts: list[str] = []
        skipped: list[str] = []
        last: UpstreamError | None = None
        # retries：同一渠道的尝试次数（对标 new-api 的可配重试）。
        # 1 = 现状（失败就换下一家）；>1 = 先在本渠道快速重试 N 次再切换，
        # 适合「上游偶发抖动」比「切渠道成本高」的场景。
        for key in candidates:
            if fp is not None and not _EXIT_GUARD.allow(
                fp, key.label, scope=guard_scope or ""
            ):
                # 出口查重：同指纹对同上游高频重发 → 跳过该候选（疑似环路）。
                # **必须记下来**：全被跳过时 attempts 是空的，下面的报错若不区分，
                # 会说出「全部 0 个渠道都失败，最后一个错误：None」这种既谎报渠道数、
                # 又谎报状态码（502 暗示上游挂了，其实是本地临时限制）的话。
                skipped.append(key.label)
                continue
            for attempt in range(max(1, self.pool.retries)):
                attempts.append(key.label if attempt == 0 else f"{key.label}#{attempt + 1}")
                try:
                    if stream:
                        return self._relay_stream(key, model, payload, attempts, trace_headers)
                    return self._relay_once(key, model, payload, attempts, trace_headers)
                except UpstreamError as exc:
                    last = exc
                    self.pool.report_failure(key, exc, trip=exc.retryable)
                    self._persist()
                    continue
        if not attempts:
            # 所有候选都被出口查重挡下：这是**本地的临时限制**，不是上游故障。
            raise RouterError(
                f"同一请求内容在 {ExitGuard.WINDOW:g} 秒内对同一上游重复过密，"
                f"已临时跳过 {len(skipped)} 个渠道"
                + (f"（{', '.join(skipped[:4])}）" if skipped else "")
                + "。这通常是自动重发或转发环路，请稍后重试。",
                status=429,
                attempts=attempts,
            )
        raise all_failed(attempts, last)

    def relay_embeddings(
        self,
        model: str,
        payload: dict[str, Any],
        trace_headers: dict[str, str] | None = None,
    ) -> tuple[dict[str, Any], str, int]:
        """转发 /v1/embeddings（非流式，与 chat 的协议翻译无关）。

        中文：embeddings 只有 OpenAI 协议形态，Anthropic 协议渠道直接跳过。
        返回 (上游 JSON, 渠道 label, tokens_in)；失败渠道按 chat 同一套熔断
        规则记账（连败进冷却），成功按 prompt_tokens 记用量。

        English: forward /v1/embeddings (non-streaming). Anthropic-protocol
        channels are skipped. Returns (JSON, channel label, tokens in).
        Failures feed the same circuit-breaker accounting as chat.
        """
        candidates = [
            key
            for key in self.pool.candidates(model)
            if key.protocol != PROTOCOL_ANTHROPIC
        ]
        if not candidates:
            declared = any(key.supports(model) for key in self.pool.keys)
            raise RouterError(
                self._no_candidate_reason(model),
                status=503 if declared else 404,
            )

        attempts: list[str] = []
        last: UpstreamError | None = None
        for key in candidates:
            attempts.append(key.label)
            try:
                data, tokens_in = call_embeddings(
                    key, {**payload, "model": key.map_to_upstream(model)},
                    self.timeout, trace_headers=trace_headers,
                )
            except UpstreamError as exc:
                last = exc
                self.pool.report_failure(key, exc, trip=exc.retryable)
                self._persist()
                continue
            self.pool.report_success(key, tokens_in, 0, 0, 0)
            self._persist()
            if isinstance(data.get("model"), str):
                data["model"] = model  # 响应里的模型名翻回对外名
            return data, key.label, tokens_in
        raise all_failed(attempts, last)

    # -- 内部 ------------------------------------------------------------

    def _relay_once(
        self,
        key: UpstreamKey,
        model: str,
        payload: dict[str, Any],
        attempts: list[str],
        trace_headers: dict[str, str] | None = None,
    ) -> RelayOutcome:
        # 模型映射：客户端发对外名，上游收真名
        upstream_model = key.map_to_upstream(model)
        reply = upstream.call_once(
            key, {**payload, "model": upstream_model}, self.timeout, trace_headers=trace_headers
        )
        self.pool.report_success(
            key, reply.tokens_in, reply.tokens_out, reply.cache_read, reply.cache_creation
        )
        self._persist()
        if isinstance(reply.message, dict) and reply.message.get("model"):
            reply.message["model"] = model  # 响应里的模型名翻回对外名
        return RelayOutcome(
            label=key.label, model=model, message=reply.message, attempts=list(attempts),
            key=key,
        )

    def _relay_stream(
        self,
        key: UpstreamKey,
        model: str,
        payload: dict[str, Any],
        attempts: list[str],
        trace_headers: dict[str, str] | None = None,
    ) -> RelayOutcome:
        sink = _TokenSink()
        upstream_model = key.map_to_upstream(model)
        events = upstream.stream_events(
            key,
            {**payload, "model": upstream_model},
            self.stream_timeout,
            on_usage=sink,
            trace_headers=trace_headers,
        )
        # peek 会真正发起连接并检查状态码；这一步失败才能安全地换 Key，
        # 因为此时我们还没向客户端写过任何字节。
        #
        # 注意必须接住返回的「剩余迭代器」：peek_first 已经把第一个事件从原生成器里
        # 取走了，原生成器上再也拿不到它。丢掉返回值 = 静默吞掉 message_start，
        # 客户端会因为事件序列不全而整个拒绝这条流。
        _first, events = upstream.peek_first(events)
        return RelayOutcome(
            label=key.label,
            key=key,
            model=model,
            events=self._guard(key, self._public_model(events, model, sink), sink),
            attempts=list(attempts),
            usage=sink,
        )

    def _public_model(
        self,
        events: Iterator[tuple[str, dict[str, Any]]],
        model: str,
        sink: _TokenSink | None = None,
    ) -> Iterator[tuple[str, dict[str, Any]]]:
        """流式事件里的模型名翻回对外名（message_start 内嵌 model 字段）；
        顺带从 message_start 的 usage 里收缓存命中量。"""
        for name, payload in events:
            if name == "message_start":
                message = payload.get("message")
                if isinstance(message, dict):
                    if message.get("model"):
                        message["model"] = model
                    if sink is not None:
                        cache_read, cache_creation = upstream.cache_from_usage(
                            message.get("usage") or {}
                        )
                        sink.cache_read = cache_read
                        sink.cache_creation = cache_creation
            yield name, payload

    def _guard(
        self,
        key: UpstreamKey,
        events: Iterator[tuple[str, dict[str, Any]]],
        sink: _TokenSink,
    ) -> Iterator[tuple[str, dict[str, Any]]]:
        """流式收尾时补记用量；中途断裂则记失败（此时已无法切换渠道）。"""
        try:
            yield from events
        except GeneratorExit:
            # 客户端主动断开：既不算成功也不算失败
            raise
        except UpstreamError as exc:
            self.pool.report_failure(key, exc, trip=exc.retryable)
            self._persist()
            raise
        except OSError as exc:
            self.pool.report_failure(key, UpstreamError(0, str(exc), True), trip=True)
            self._persist()
            raise
        else:
            self.pool.report_success(
                key,
                sink.input,
                sink.output,
                getattr(sink, "cache_read", 0),
                getattr(sink, "cache_creation", 0),
            )
            self._persist()

    def _persist(self) -> None:
        if self.persist_path:
            self.pool.save(self.persist_path)

    def _no_candidate_reason(self, model: str) -> str:
        if not self.pool.keys:
            return "号池是空的，先用 `relayhub.gateway pool add` 添加上游 Key"
        matched = [k.label for k in self.pool.keys if k.supports(model)]
        if not matched:
            return (
                f"没有任何 Key 声明支持模型 {model}。已配置的模型有："
                f"{sorted({m for k in self.pool.keys for m in k.models})}"
            )
        # 「不可用」有两种，排查方向完全不同，所以分开报：
        # 你手动禁用的是一个意思，熔断闸跳了是另一个意思。
        now = self.pool.now()
        disabled = [k.label for k in self.pool.keys if k.supports(model) and not k.enabled]
        cooling = [
            k.label
            for k in self.pool.keys
            if k.supports(model) and k.enabled and not k.is_available(now)
        ]
        reasons = []
        if disabled:
            reasons.append(f"已禁用：{disabled}")
        if cooling:
            reasons.append(f"熔断冷却中：{cooling}")
        tier_text = "/".join(
            f"{name}:{seconds:g}s" for name, seconds in self.pool.cooldown_tiers.items()
        )
        return (
            f"模型 {model} 的 {len(matched)} 个渠道全部不可用（{'；'.join(reasons)}；"
            f"阈值 {self.pool.failure_threshold} 次 / 冷却档位 {tier_text}）"
        )


# ---------------------------------------------------------------- 号池热加载

# 这些字段只反映「服务过程中的状态」，不参与选路配置。
# credits 不在其中：它是人/脚本记录的选路输入（most_credits 策略用），改了必须触发 reload。
_RUNTIME_ONLY_FIELDS = (
    "usage",
    "consecutive_failures",
    "disabled_until",
    "cooldown_tier",
    "last_error",
)


_UNREADABLE = object()  # 指纹哨兵：「读不到」≠「没变化」，也 ≠「变了」


def config_fingerprint(path: Path) -> object:
    """号池文件的「配置指纹」——只算影响选路的字段。

    **刻意排除 usage / 熔断状态**。因为中转站每服务一个请求就会把用量落盘；
    若把运行时字段算进指纹，就退化成「每个请求 reload 一次」，round-robin 游标
    被反复重置，轮询直接变成「永远挑第一个 Key」。这个坑很隐蔽：
    测试里单请求都能过，只有连续请求才暴露。

    返回值三种语义，**务必区分**：
      * `str`        —— 读到了，这是内容指纹；
      * `_UNREADABLE`—— 文件正在被写/暂时读不到（撕裂读、权限、不存在）。
                        **不是「配置变了」**，调用方应保持现有 router 不动。
                        （早期版本这里返回 None，与「指纹变了」不可区分，导致
                        并发下每次空读都触发一次 reload → 500。）
    """
    try:
        # 必须解封后再算：加密落盘后每次密文都不同，按字节算会让指纹永远在变，
        # 变成「每请求 reload」——round-robin 游标被反复重置，轮询退化成永远挑第一个。
        raw = secretbox.unseal(Path(path))
        if raw is None:
            raise ValueError("unreadable")
    except (OSError, json.JSONDecodeError, ValueError):
        return _UNREADABLE
    if not isinstance(raw, dict):
        return _UNREADABLE
    stripped: dict[str, Any] = {k: v for k, v in raw.items() if k != "keys"}
    stripped["keys"] = [
        {k: v for k, v in item.items() if k not in _RUNTIME_ONLY_FIELDS}
        for item in raw.get("keys") or []
        if isinstance(item, dict)
    ]
    blob = json.dumps(stripped, sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(blob.encode("utf-8")).hexdigest()


class ReloadingRouter:
    """包住 KeyPoolRouter：号池文件被外部改动（比如刚跑了一次 `pool add`）就重新加载。

    为什么不干脆重启中转站：重启会掐掉正在处理的客户端手上的在途请求。
    运维机上加一个上游 Key 不该有这个副作用。

    **并发安全**：本类每请求都会探测指纹。文件正被另一个进程重写的瞬间，
    读到的可能是空/半截内容——此时必须「按兵不动」沿用现有路由表，
    绝不能 reload（那正是 0.9.0 并发 500 的根因）。
    """

    def __init__(self, pool_path: Path, **kwargs: Any) -> None:
        self.pool_path = Path(pool_path)
        self._kwargs = kwargs
        self._lock = threading.Lock()
        # 先记指纹再构建：万一构建期间文件变了，最坏是多 reload 一次（无害）；
        # 反过来则会「拿着旧 router 配着新指纹」，从此永不刷新。
        self._fingerprint = config_fingerprint(self.pool_path)
        self._router = self._build()

    @property
    def pool(self) -> KeyPool:
        return self._current().pool

    def stats(self) -> dict:
        return self._current().pool.stats()

    def _build(self) -> KeyPoolRouter:
        return KeyPoolRouter(
            KeyPool.load(self.pool_path), persist_path=self.pool_path, **self._kwargs
        )

    def _current(self) -> KeyPoolRouter:
        fingerprint = config_fingerprint(self.pool_path)
        # 读不到（正在被写）→ 保持现状。这是「空读」与「真变更」的分界点：
        # 前者绝不能触发 reload，否则并发下每次撕裂读都会重建路由表并裸读文件。
        if fingerprint is _UNREADABLE or fingerprint == self._fingerprint:
            return self._router
        with self._lock:
            fingerprint = config_fingerprint(self.pool_path)
            if fingerprint is _UNREADABLE or fingerprint == self._fingerprint:
                return self._router
            try:
                new_router = self._build()
            except Exception:  # noqa: BLE001 - 配置暂时读不全：沿用旧表，别把请求打成 500
                return self._router
            self._router = new_router
            self._fingerprint = fingerprint
        return self._router

    # -- 与 KeyPoolRouter 同形 -------------------------------------------
    #
    # ⚠️ 签名必须与 KeyPoolRouter **逐参对齐**（含 group）。差一个参数，
    # service.py 的 `except TypeError` 降级链就会在生产上悄悄触发——
    # 不止丢掉 group（渠道组隔离失效），还会连带丢掉 trace_headers
    # （链路追踪）与 fp（语义指纹/缓存键），而请求看起来完全正常。
    # 这里曾经漏了 group，正好中了这一枪。

    def models(self, group: str | None = None) -> dict[str, int]:
        return self._current().models(group=group)

    def relay(
        self,
        model: str,
        payload: dict[str, Any],
        stream: bool,
        trace_headers: dict[str, str] | None = None,
        fp: str | None = None,
        group: str | None = None,
    ) -> RelayOutcome:
        return self._current().relay(
            model, payload, stream, trace_headers=trace_headers, fp=fp, group=group
        )

    def relay_embeddings(
        self,
        model: str,
        payload: dict[str, Any],
        trace_headers: dict[str, str] | None = None,
    ) -> tuple[dict[str, Any], str, int]:
        """与 KeyPoolRouter.relay_embeddings 同形（热加载包装）。/ Same shape as KeyPoolRouter.relay_embeddings."""
        return self._current().relay_embeddings(model, payload, trace_headers=trace_headers)
