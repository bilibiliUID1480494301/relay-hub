from relayhub import pricing
from relayhub.gateway.providers import _balance

SAMPLE = {
    "data": [
        {"model_name": "gpt-6-astra", "model_ratio": 37.5, "completion_ratio": 2,
         "enable_groups": ["gpt"], "vendor_id": 5,
         "supported_endpoint_types": ["openai", "anthropic", "gemini"],
         "billing_mode": "tiered_expr", "billing_expr": "tier(\"base\", p * 10)"},
        {"model_name": "deepseek-flash", "model_ratio": 37.5, "completion_ratio": 1,
         "enable_groups": ["0.3x", "vip"], "vendor_id": 1,
         "supported_endpoint_types": ["openai", "openai-response", "anthropic", "gemini"],
         "billing_expr": "hour(\"Asia/Shanghai\") ? tier(\"base\", p * 2) : tier(\"base\", p * 1)"},
    ],
    "group_ratio": {"0.3x": 0.3, "gpt": 0.1, "vip": 0.5},
    "supported_endpoint": {"anthropic": {}, "gemini": {}, "openai": {}, "openai-response": {}},
    "vendors": [{"id": 1, "name": "DeepSeek"}, {"id": 5, "name": "OpenAI"}],
    "pricing_version": "a42d3",
}


def test_parse_pricing_summarises_models_groups_and_endpoints():
    out = pricing.parse(SAMPLE)
    assert out["count"] == 2
    assert [m["model"] for m in out["models"]] == ["deepseek-flash", "gpt-6-astra"]
    astra = out["models"][1]
    assert astra["vendor"] == "OpenAI"
    assert astra["groups"] == ["gpt"]
    assert "gemini" in astra["endpoints"]
    assert out["group_ratio"]["vip"] == 0.5
    assert out["endpoints"] == ["anthropic", "gemini", "openai", "openai-response"]
    assert out["pricing_version"] == "a42d3"


def test_relayhub_balance_parses_quota_minus_used():
    bal = _balance("relayhub", {"quota": 1000, "used": 250})
    assert bal["amount"] == 750
    assert bal["currency"] == "points"
